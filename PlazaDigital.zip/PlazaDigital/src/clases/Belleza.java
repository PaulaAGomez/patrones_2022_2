/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Belleza extends Categoria implements ICategoriaMyC {

    public Belleza() {
        super.setNombre("Belleza");
    }
    
    public String beneficioProd (){
        return "Este producto est� publicado par satisfacer sus necesidades respecto a la belleza";
    }
    
    public void myCategoria (){
        System.out.println("La categoria de este producto es: Belleza");
    }
}