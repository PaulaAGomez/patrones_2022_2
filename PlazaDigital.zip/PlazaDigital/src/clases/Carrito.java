/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Carrito {
    private int cantProd;
    private Pago medioPago;
    private Producto [] productos;
    private int count;
    Scanner in = new Scanner (System.in);

    public Carrito(int cantProd) {
        this.cantProd = cantProd;
    }

    public int getCantProd() {
        return cantProd;
    }

    public void setCantProd(int cantProd) {
        this.cantProd = cantProd;
    }

    public Pago getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(Pago medioPago) {
        this.medioPago = medioPago;
    }

    public Producto[] getProductos() {
        return productos;
    }

    public void setProductos(Producto[] productos) {
        this.productos = productos;
    }
    
    public void agregarProductos (Producto producto){
        if(count<cantProd)
            productos[count]=producto;
        else{
            System.out.println("No tiene mas espacio disponible en su carrito. Ingrese la nueva capacidad que desea que tenga su carrito: ");
            int cap=in.nextInt();
            in.nextLine();
            boolean cambioCorrecto;
            do{
                cambioCorrecto=cambiarCantProd(cap);
                if (cambioCorrecto)
                    productos[count]=producto;
            }while(!cambioCorrecto);
        }
    }
    
    private boolean cambiarCantProd (int newCant){
        if(newCant<=cantProd){
            System.out.println("Debe ingresar una cantidad mayor que la actual. Intente nuevamente");
            return false;
        }
        else{
            Producto [] temp = new Producto [newCant];
            for(int i = 0; i<count; i++){
                temp[i] = productos[i];  
            }
            productos = temp;
            System.out.println("Se aumento la cantidad de productos que puede llevar en su carrito");
            return true;
        }
    }
    
    public void elegirMedioPago (){
        ComponentGeneral cc = new ComponentGeneral();
        boolean medioPagoAceptado=true;
        do{
            System.out.println("Elija su medio de pago"
                                + "1.Efectivo"
                                + "2.Tarjeta credito"
                                + "3.Tareta debito");
            int opc= in.nextInt();
            in.nextLine();
            double dinero;
            switch(opc){
                case 1:
                    Efectivo efect = new Efectivo();
                    efect.setTheComponent(cc);
                    System.out.print("Con cu�nto va a pagar sus productos: ");
                    dinero=in.nextDouble();
                    in.nextLine();
                    efect=(Efectivo)efect.soliciarDatos(dinero);
                    if(dinero<calcularTotalCompra()){
                        medioPagoAceptado=false;
                        System.out.println("Su dinero no es suficiente para realizar la compra. Intente nuevamente");
                    }
                    else
                        System.out.println("Se realizo satisfactoriamente el pago");
                    break;
                case 2:
                    TarjetaCredito tarjC = new TarjetaCredito(" ");
                    tarjC.setTheComponent(cc);
                    System.out.print("Cu�nto cupo tiene en su tarjeta: ");
                    dinero=in.nextDouble();
                    in.nextLine();
                    tarjC=(TarjetaCredito)tarjC.soliciarDatos(dinero);
                    if(dinero<calcularTotalCompra()){
                        medioPagoAceptado=false;
                        System.out.println("Su dinero no es suficiente para realizar la compra. Intente nuevamente");
                    }
                    else
                        System.out.println("Se realizo satisfactoriamente el pago");
                    break;
                case 3:
                    TarjetaDebito tarjD = new TarjetaDebito(" ");
                    tarjD.setTheComponent(cc);
                    System.out.print("Cu�nto saldo tiene en su tarjeta: ");
                    dinero=in.nextDouble();
                    in.nextLine();
                    tarjD=(TarjetaDebito)tarjD.soliciarDatos(dinero);
                    if(dinero<calcularTotalCompra()){
                        medioPagoAceptado=false;
                        System.out.println("Su dinero no es suficiente para realizar la compra. Intente nuevamente");
                    }
                    else
                        System.out.println("Se realizo satisfactoriamente el pago");
                    break;
                default: 
                    System.out.println("Opcion incorrecta, intente nuevamente");
            }
        }while(!medioPagoAceptado);
    }
    
    public double calcularTotalCompra (){
        double total=0;
        for(int i=0; i<count; i++)
            total+= productos[i].getPrecio();
        return total;
    }
    
    public boolean retirarProd (Producto producto){
        for(int i=0; i<count; i++){
            if(productos[i].equals(producto)){
                for(int j=i; j<count-1; i++)
                    productos[j]=productos[j+1];
                return true;
            }
        }
        return false;
    }
}