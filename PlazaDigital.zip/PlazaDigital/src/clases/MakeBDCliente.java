/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class MakeBDCliente {
    private static MakeBDCliente cliente;

    public MakeBDCliente() {
        ArrayList <Cliente> listClie = new ArrayList <Cliente> ();
    }
    
    public static MakeBDCliente getBDCliente ( ){
        if (cliente == null) {
            cliente = new MakeBDCliente();
        }
        return cliente;
    }
}