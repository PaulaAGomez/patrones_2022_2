/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Producto {
    private final String nombre;
    private final String referencia;
    private final String palabraClave;
    private String descripcion;
    private String estado;
    private double precio;
    private int disponibilidad;
    private int vendidos;
    private final Categoria categoria;

    public Producto(String nombre, String referencia, String palabraClave, String descripcion, String estado, double precio, int disponibilidad, Categoria categoria) {
        this.nombre = nombre;
        this.referencia = referencia;
        this.palabraClave = palabraClave;
        this.descripcion = descripcion;
        this.estado = estado;
        this.precio = precio;
        this.disponibilidad = disponibilidad;
        this.categoria = categoria;
        vendidos=0;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(int disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public int getVendidos() {
        return vendidos;
    }

    public void setVendidos(int vendidos) {
        this.vendidos = vendidos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getReferencia() {
        return referencia;
    }

    public String getPalabraClave() {
        return palabraClave;
    }

    public Categoria getCategoria() {
        return categoria;
    }
}